from setuptools import setup

setup(
  name = 'segunda-pre-entrega',
  version = '0.1.0',
  description = 'Segunda pre entrega',
  author = 'Ricardo Agustin Gonzalez',
  author_email='agustin_.gonzalez_@hotmail.com',
  packages = ['modules'],
)